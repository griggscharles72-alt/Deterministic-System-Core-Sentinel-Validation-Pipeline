
import sqlite3, os, time

DB_PATH = "data/db/system.db"

def init_db():
    os.makedirs("data/db", exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS runs (id TEXT, profile TEXT, ts REAL)")
    conn.commit()
    conn.close()

def record_run(profile):
    init_db()
    rid = str(time.time())
    conn = sqlite3.connect(DB_PATH)
    conn.execute("INSERT INTO runs VALUES (?,?,?)",(rid,profile,time.time()))
    conn.commit()
    conn.close()
    return rid
