
import hashlib

def object_id(type_name, key):
    return hashlib.sha256((type_name+key).encode()).hexdigest()
