
from deterministic_system.console.cli import app
