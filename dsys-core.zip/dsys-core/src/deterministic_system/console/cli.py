
import typer
from rich import print
from deterministic_system.memory.db import init_db, record_run

app = typer.Typer()

@app.command()
def doctor():
    print("[green]Environment OK[/green]")

@app.command()
def ingest():
    rid = record_run("ingest")
    print(f"[blue]Run recorded[/blue]: {rid}")

@app.command()
def verify():
    print("[yellow]Sentinel verification placeholder[/yellow]")

@app.command()
def report():
    print("[cyan]Report placeholder[/cyan]")

@app.command()
def history():
    print("[magenta]History placeholder[/magenta]")

@app.command()
def reset():
    print("[red]Reset placeholder[/red]")

if __name__ == "__main__":
    init_db()
    app()
