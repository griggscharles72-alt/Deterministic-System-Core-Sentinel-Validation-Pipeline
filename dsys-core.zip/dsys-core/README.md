
# Deterministic Sentinel Pipeline

A deterministic state pipeline:

Raw → Normalize → Waffle → Sentinel → Memory → Reports

Identical inputs and configuration produce identical system state.

## Quick Start

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
./bin/dsys doctor
```

## CLI

doctor – environment check  
ingest – create staged record  
verify – sentinel validation  
report – summary output  
history – show stored runs  
reset – clear state
