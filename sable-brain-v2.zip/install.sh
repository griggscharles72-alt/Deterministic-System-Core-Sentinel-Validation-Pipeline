#!/usr/bin/env bash
set -euo pipefail

# SABLE Brain v2 installer (local machine)
# Installs into /opt/sable-brain-v2 by default and optionally sets up systemd system service.

PREFIX="${PREFIX:-/opt/sable-brain-v2}"
PYTHON="${PYTHON:-python3}"

echo "[*] Installing to: $PREFIX"
sudo mkdir -p "$PREFIX"
sudo rsync -a --delete "./" "$PREFIX/"

echo "[*] Creating venv"
sudo $PYTHON -m venv "$PREFIX/.venv"
sudo "$PREFIX/.venv/bin/python" -m pip install -U pip >/dev/null

echo "[*] Creating var dirs"
sudo mkdir -p "$PREFIX/var/logs"

echo "[*] Done."
echo
echo "Run:"
echo "  cd $PREFIX"
echo "  sudo $PREFIX/.venv/bin/python -m brain repl"
echo
echo "Systemd system service example:"
echo "  sudo cp $PREFIX/systemd/brain.service /etc/systemd/system/sable-brain.service"
echo "  sudo systemctl daemon-reload"
echo "  sudo systemctl enable --now sable-brain.service"
