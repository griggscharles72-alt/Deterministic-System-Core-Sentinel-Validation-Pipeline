# SABLE Brain v2 (local, durable, boring)

A single "brain" process that runs in a loop (REPL), persists memory to SQLite, streams responses from a local Ollama server, and provides ops commands.

## Quick start

Requirements:
- Python 3.10+
- Ollama running locally (default: http://127.0.0.1:11434)

Run:
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
# no deps required (stdlib only)
python -m brain repl
```

## Configuration

All config is optional; defaults are sane.

Env vars:
- `BRAIN_DB` (default: `./var/brain.db`)
- `BRAIN_LOG` (default: `./var/logs/brain.jsonl`)
- `BRAIN_MODEL` (default: `llama3`)
- `BRAIN_OLLAMA_URL` (default: `http://127.0.0.1:11434`)
- `BRAIN_MAX_INPUT_CHARS` (default: `8000`)
- `BRAIN_RECENT_TURNS` (default: `14`)
- `BRAIN_SUMMARIZE_EVERY` (default: `12`)  # 0 disables auto summary
- `BRAIN_TIMEOUT_S` (default: `120`)

CLI flags override env vars. See:
```bash
python -m brain --help
python -m brain repl --help
```

## REPL commands

Inside `repl`:
- `/help`
- `/exit` `/quit`
- `/diag` (capabilities + paths)
- `/health` (quick checks)
- `/save` (force DB commit)
- `/raw on|off` (bypass output validation)
- `/log on|off` (toggle jsonl logging)
- `/mem show` (show latest summary + facts count + recent turns count)
- `/facts` (list facts)
- `/remember key=value` (set fact)
- `/forget key` (delete fact)
- `/retry N` (re-run last user prompt N times without writing to memory)

## Systemd (optional)

A sample service is in `systemd/brain.service`. For a quick install on a single host, use `install.sh`.

## Design notes

- SQLite uses WAL and durable settings.
- Turn storage is append-only; facts are keyed.
- Summaries are stored as rolling "latest summary".
- No network access beyond your local Ollama URL.
