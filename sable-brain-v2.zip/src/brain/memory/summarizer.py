from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple

@dataclass
class SummarizerConfig:
    summarize_every: int = 12

SUMMARY_SYSTEM = """You are a summarizer.
Write a concise rolling summary of the conversation so far.
Keep:
- user goals
- decisions/spec
- file paths / commands
- constraints
Avoid fluff.
Return plain text only.
"""

def should_summarize(turn_count: int, summarize_every: int) -> bool:
    if summarize_every <= 0:
        return False
    return (turn_count % summarize_every) == 0

def build_summary_prompt(latest_summary: str, turns: List[Tuple[str, str]]) -> str:
    parts = [SUMMARY_SYSTEM.strip()]
    if latest_summary.strip():
        parts.append("\n[PREVIOUS SUMMARY]\n" + latest_summary.strip())
    parts.append("\n[NEW TURNS]\n")
    for role, content in turns:
        parts.append(f"{role.upper()}: {content}")
    parts.append("\n[SUMMARY]\n")
    return "\n".join(parts)
