from __future__ import annotations
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

@dataclass
class StoreConfig:
    path: Path

class MemoryStore:
    def __init__(self, cfg: StoreConfig):
        self.cfg = cfg
        self._conn: Optional[sqlite3.Connection] = None

    def connect(self) -> None:
        self.cfg.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.cfg.path), timeout=30, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        self._apply_pragmas()
        self.init_schema()

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError("DB not connected")
        return self._conn

    def _apply_pragmas(self) -> None:
        c = self.conn
        c.execute("PRAGMA journal_mode=WAL;")
        c.execute("PRAGMA synchronous=NORMAL;")
        c.execute("PRAGMA temp_store=MEMORY;")
        c.execute("PRAGMA foreign_keys=ON;")

    def init_schema(self) -> None:
        c = self.conn
        c.execute(
            '''
            CREATE TABLE IF NOT EXISTS turns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts DATETIME DEFAULT CURRENT_TIMESTAMP,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                meta_json TEXT DEFAULT '{}'
            );
            '''
        )
        c.execute("CREATE INDEX IF NOT EXISTS idx_turns_ts ON turns(ts);")
        c.execute("CREATE INDEX IF NOT EXISTS idx_turns_role ON turns(role);")

        c.execute(
            '''
            CREATE TABLE IF NOT EXISTS facts (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                confidence REAL DEFAULT 1.0,
                source_turn_id INTEGER,
                updated_ts DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(source_turn_id) REFERENCES turns(id) ON DELETE SET NULL
            );
            '''
        )

        c.execute(
            '''
            CREATE TABLE IF NOT EXISTS summaries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts DATETIME DEFAULT CURRENT_TIMESTAMP,
                kind TEXT NOT NULL,
                from_turn_id INTEGER,
                to_turn_id INTEGER,
                summary TEXT NOT NULL
            );
            '''
        )
        c.execute("CREATE INDEX IF NOT EXISTS idx_summaries_ts ON summaries(ts);")

        c.execute(
            '''
            CREATE TABLE IF NOT EXISTS meta (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_ts DATETIME DEFAULT CURRENT_TIMESTAMP
            );
            '''
        )

    def add_turn(self, role: str, content: str, meta_json: str = "{}") -> int:
        cur = self.conn.execute(
            "INSERT INTO turns(role, content, meta_json) VALUES (?, ?, ?)",
            (role, content, meta_json),
        )
        return int(cur.lastrowid)

    def recent_turns(self, n: int) -> List[Tuple[str, str]]:
        rows = self.conn.execute(
            "SELECT role, content FROM turns ORDER BY id DESC LIMIT ?",
            (max(0, int(n)),),
        ).fetchall()
        rows = list(reversed(rows))
        return [(r["role"], r["content"]) for r in rows]

    def turns_count(self) -> int:
        return int(self.conn.execute("SELECT COUNT(*) AS c FROM turns").fetchone()["c"])

    def facts_set(self, key: str, value: str, confidence: float = 1.0, source_turn_id: Optional[int] = None) -> None:
        self.conn.execute(
            '''
            INSERT INTO facts(key, value, confidence, source_turn_id)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(key) DO UPDATE SET
              value=excluded.value,
              confidence=excluded.confidence,
              source_turn_id=excluded.source_turn_id,
              updated_ts=CURRENT_TIMESTAMP
            ''',
            (key, value, float(confidence), source_turn_id),
        )

    def facts_delete(self, key: str) -> bool:
        cur = self.conn.execute("DELETE FROM facts WHERE key=?", (key,))
        return cur.rowcount > 0

    def facts_list(self) -> List[Tuple[str, str, float]]:
        rows = self.conn.execute(
            "SELECT key, value, confidence FROM facts ORDER BY updated_ts DESC"
        ).fetchall()
        return [(r["key"], r["value"], float(r["confidence"])) for r in rows]

    def facts_count(self) -> int:
        return int(self.conn.execute("SELECT COUNT(*) AS c FROM facts").fetchone()["c"])

    def save_rolling_summary(self, summary: str, from_turn_id: int, to_turn_id: int) -> None:
        self.conn.execute(
            "INSERT INTO summaries(kind, from_turn_id, to_turn_id, summary) VALUES ('rolling', ?, ?, ?)",
            (int(from_turn_id), int(to_turn_id), summary),
        )
        sid = int(self.conn.execute("SELECT last_insert_rowid()").fetchone()[0])
        self.conn.execute(
            '''
            INSERT INTO meta(key, value) VALUES ('latest_summary_id', ?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_ts=CURRENT_TIMESTAMP
            ''',
            (str(sid),),
        )

    def latest_summary(self) -> str:
        row = self.conn.execute(
            '''
            SELECT s.summary
            FROM summaries s
            JOIN meta m ON m.key='latest_summary_id' AND CAST(m.value AS INTEGER)=s.id
            '''
        ).fetchone()
        return row["summary"] if row else ""

    def get_meta_int(self, key: str, default: int = 0) -> int:
        row = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        if not row:
            return int(default)
        try:
            return int(row["value"])
        except Exception:
            return int(default)

    def set_meta_int(self, key: str, value: int) -> None:
        self.conn.execute(
            '''
            INSERT INTO meta(key, value) VALUES (?, ?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_ts=CURRENT_TIMESTAMP
            ''',
            (key, str(int(value))),
        )
