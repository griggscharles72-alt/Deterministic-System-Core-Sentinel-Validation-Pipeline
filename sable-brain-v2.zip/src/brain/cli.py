from __future__ import annotations
import argparse
import os
from pathlib import Path

from .repl import Repl, ReplConfig

def env(name: str, default: str) -> str:
    return os.environ.get(name, default)

def env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, str(default)))
    except Exception:
        return int(default)

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="brain", description="SABLE Brain v2")
    p.add_argument("--db", default=env("BRAIN_DB", "./var/brain.db"), help="SQLite DB path")
    p.add_argument("--log", default=env("BRAIN_LOG", "./var/logs/brain.jsonl"), help="JSONL log path")
    p.add_argument("--model", default=env("BRAIN_MODEL", "llama3"), help="Ollama model name")
    p.add_argument("--ollama-url", default=env("BRAIN_OLLAMA_URL", "http://127.0.0.1:11434"), help="Ollama base URL")
    p.add_argument("--max-input-chars", type=int, default=env_int("BRAIN_MAX_INPUT_CHARS", 8000))
    p.add_argument("--recent-turns", type=int, default=env_int("BRAIN_RECENT_TURNS", 14))
    p.add_argument("--summarize-every", type=int, default=env_int("BRAIN_SUMMARIZE_EVERY", 12))
    p.add_argument("--timeout-s", type=int, default=env_int("BRAIN_TIMEOUT_S", 120))
    p.add_argument("--no-log", action="store_true", help="Disable jsonl logging")
    p.add_argument("--raw", action="store_true", help="Bypass output validation (currently no-op)")
    p.add_argument("--tts", action="store_true", help="Enable TTS if tts.say exists")
    p.add_argument("--no-tts", action="store_true", help="Force disable TTS")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("repl", help="Run interactive REPL")
    return p

def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    cfg = ReplConfig(
        db_path=Path(args.db),
        log_path=Path(args.log),
        model=args.model,
        ollama_url=args.ollama_url,
        max_input_chars=args.max_input_chars,
        recent_turns=args.recent_turns,
        summarize_every=args.summarize_every,
        raw_mode=bool(args.raw),
        log_enabled=not bool(args.no_log),
        tts_enabled=bool(args.tts) and not bool(args.no_tts),
        model_timeout_s=int(args.timeout_s),
    )

    say_fn = None
    if cfg.tts_enabled:
        try:
            from tts import say as say_fn  # optional external module in your project
        except Exception:
            say_fn = None
            cfg.tts_enabled = False

    if args.cmd == "repl":
        Repl(cfg, say_fn=say_fn).loop()
        return 0

    parser.error("unknown command")
    return 2
