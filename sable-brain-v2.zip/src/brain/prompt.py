from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple

SYSTEM_PROMPT = """You are SABLE CORE.
- Localhost execution brain.
- Be direct, technical, deterministic.
- If user asks for code: give runnable code blocks.
- Prefer minimal output unless asked for depth.
"""

@dataclass
class PromptConfig:
    recent_turns: int = 14

def build_prompt(latest_summary: str, facts: List[Tuple[str, str, float]], recent: List[Tuple[str, str]], user_text: str) -> str:
    parts = [SYSTEM_PROMPT.strip()]

    if latest_summary.strip():
        parts.append("\n[ROLLING SUMMARY]\n" + latest_summary.strip())

    if facts:
        lines = [f"- {k} = {v} (c={c:.2f})" for k, v, c in facts[:50]]
        parts.append("\n[FACTS]\n" + "\n".join(lines))

    if recent:
        parts.append("\n[RECENT TURNS]\n")
        for role, content in recent:
            parts.append(f"{role.upper()}: {content}")

    parts.append("\n[USER]\n" + user_text.strip())
    parts.append("\n[ASSISTANT]\n")
    return "\n".join(parts)
