from __future__ import annotations
from dataclasses import dataclass
from typing import Iterator, Protocol, Tuple, Union

Stream = Iterator[str]

@dataclass
class ModelConfig:
    model: str
    base_url: str = "http://127.0.0.1:11434"
    timeout_s: int = 120

class ModelAdapter(Protocol):
    cfg: ModelConfig
    def generate(self, prompt: str, stream: bool = True) -> Union[str, Stream]:
        ...
    def health(self) -> Tuple[bool, str]:
        ...
