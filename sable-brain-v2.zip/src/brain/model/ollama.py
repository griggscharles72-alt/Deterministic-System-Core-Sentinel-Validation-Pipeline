from __future__ import annotations
import json
import urllib.request
from typing import Iterator, Tuple, Union

from .base import ModelConfig

class OllamaAdapter:
    def __init__(self, cfg: ModelConfig):
        self.cfg = cfg

    def _url(self, path: str) -> str:
        return self.cfg.base_url.rstrip("/") + path

    def health(self) -> Tuple[bool, str]:
        try:
            req = urllib.request.Request(self._url("/api/tags"), method="GET")
            with urllib.request.urlopen(req, timeout=10) as resp:
                if 200 <= resp.status < 300:
                    return True, "ok"
                return False, f"status {resp.status}"
        except Exception as e:
            return False, f"{type(e).__name__}: {e}"

    def generate(self, prompt: str, stream: bool = True) -> Union[str, Iterator[str]]:
        payload = {"model": self.cfg.model, "prompt": prompt, "stream": bool(stream)}
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self._url("/api/generate"),
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        return self._stream(req) if stream else self._single(req)

    def _single(self, req: urllib.request.Request) -> str:
        with urllib.request.urlopen(req, timeout=self.cfg.timeout_s) as resp:
            raw = resp.read().decode("utf-8", errors="ignore")
        try:
            obj = json.loads(raw)
            return obj.get("response", "") or ""
        except Exception:
            return raw

    def _stream(self, req: urllib.request.Request) -> Iterator[str]:
        with urllib.request.urlopen(req, timeout=self.cfg.timeout_s) as resp:
            for line in resp:
                s = line.decode("utf-8", errors="ignore").strip()
                if not s:
                    continue
                try:
                    obj = json.loads(s)
                except Exception:
                    continue
                chunk = obj.get("response", "")
                if chunk:
                    yield chunk
                if obj.get("done") is True:
                    break
