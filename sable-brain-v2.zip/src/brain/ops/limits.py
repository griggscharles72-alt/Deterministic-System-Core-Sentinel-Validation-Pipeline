from __future__ import annotations
import signal
from contextlib import contextmanager

class Timeout(Exception):
    pass

@contextmanager
def time_limit(seconds: int):
    if seconds <= 0:
        yield
        return

    def _handler(_signum, _frame):
        raise Timeout(f"timeout after {seconds}s")

    old = signal.signal(signal.SIGALRM, _handler)
    try:
        signal.alarm(seconds)
        yield
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, old)
