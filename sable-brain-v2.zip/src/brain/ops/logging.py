from __future__ import annotations
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

from ..util.fs import ensure_dir
from ..util.time import now_ts

@dataclass
class JsonlLogger:
    path: Path
    enabled: bool = True

    def log(self, role: str, content: str, meta: Optional[Dict[str, Any]] = None) -> None:
        if not self.enabled:
            return
        try:
            ensure_dir(self.path.parent)
            rec = {"ts": now_ts(), "role": role, "content": content, "meta": meta or {}}
            with self.path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception:
            pass
