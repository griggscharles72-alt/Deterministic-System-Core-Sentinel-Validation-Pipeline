from __future__ import annotations
import os
import sys
from dataclasses import dataclass
from pathlib import Path

from .memory.store import MemoryStore, StoreConfig
from .memory.summarizer import should_summarize, build_summary_prompt
from .prompt import build_prompt
from .model.base import ModelConfig
from .model.ollama import OllamaAdapter
from .ops.logging import JsonlLogger
from .util.text import truncate
from .util.time import now_ts

@dataclass
class ReplConfig:
    db_path: Path
    log_path: Path
    model: str
    ollama_url: str
    max_input_chars: int = 8000
    recent_turns: int = 14
    summarize_every: int = 12
    raw_mode: bool = False
    log_enabled: bool = True
    tts_enabled: bool = False
    model_timeout_s: int = 120

class Repl:
    def __init__(self, cfg: ReplConfig, say_fn=None):
        self.cfg = cfg
        self.say_fn = say_fn
        self.store = MemoryStore(StoreConfig(path=cfg.db_path))
        self.store.connect()
        self.model = OllamaAdapter(ModelConfig(model=cfg.model, base_url=cfg.ollama_url, timeout_s=cfg.model_timeout_s))
        self.logger = JsonlLogger(path=cfg.log_path, enabled=cfg.log_enabled)
        self.last_user: str = ""

    def banner(self) -> None:
        print("-" * 78)
        print("SABLE Brain v2 — REPL online")
        print(f"db={self.cfg.db_path}  log={self.cfg.log_path}")
        print(f"model={self.cfg.model}  ollama={self.cfg.ollama_url}")
        print("Type /help")
        print("-" * 78)

    def cmd_help(self) -> None:
        print("-" * 78)
        print("Commands:")
        print("  /help")
        print("  /exit | /quit")
        print("  /diag")
        print("  /health")
        print("  /save")
        print("  /raw on|off")
        print("  /log on|off")
        print("  /mem show")
        print("  /facts")
        print("  /remember key=value")
        print("  /forget key")
        print("  /retry N")
        print("-" * 78)

    def cmd_diag(self) -> None:
        ok, msg = self.model.health()
        print("-" * 78)
        print("DIAG")
        print(f"time: {now_ts()}")
        print(f"cwd:  {os.getcwd()}")
        print(f"db:   {self.cfg.db_path} (turns={self.store.turns_count()} facts={self.store.facts_count()})")
        print(f"log:  {self.cfg.log_path} (enabled={self.logger.enabled})")
        print(f"model health: {ok} ({msg})")
        print(f"raw_mode={self.cfg.raw_mode} summarize_every={self.cfg.summarize_every} recent_turns={self.cfg.recent_turns}")
        print("-" * 78)

    def cmd_health(self) -> None:
        ok, msg = self.model.health()
        try:
            _ = self.store.add_turn("health", "ping", "{}")
            db_ok = True
            db_msg = ""
        except Exception as e:
            db_ok = False
            db_msg = f"{type(e).__name__}: {e}"
        print(f"model: {ok} ({msg})")
        print(f"db:    {db_ok}" + ("" if db_ok else f" ({db_msg})"))

    def cmd_mem_show(self) -> None:
        summary = self.store.latest_summary().strip()
        print("-" * 78)
        print(f"latest_summary: {('present' if summary else 'none')}")
        if summary:
            print(summary)
        print(f"facts={self.store.facts_count()} turns={self.store.turns_count()}")
        print("-" * 78)

    def cmd_facts(self) -> None:
        facts = self.store.facts_list()
        if not facts:
            print("(no facts)")
            return
        for k, v, c in facts:
            print(f"- {k} = {v} (c={c:.2f})")

    def cmd_remember(self, arg: str) -> None:
        if "=" not in arg:
            print("(usage: /remember key=value)")
            return
        k, v = arg.split("=", 1)
        k = k.strip()
        v = v.strip()
        if not k:
            print("(bad key)")
            return
        self.store.facts_set(k, v, 1.0, None)
        print("(remembered)")

    def cmd_forget(self, key: str) -> None:
        key = key.strip()
        if not key:
            print("(usage: /forget key)")
            return
        ok = self.store.facts_delete(key)
        print("(deleted)" if ok else "(not found)")

    def cmd_raw(self, onoff: str) -> None:
        v = onoff.strip().lower()
        if v in ("on", "1", "true", "yes"):
            self.cfg.raw_mode = True
        elif v in ("off", "0", "false", "no"):
            self.cfg.raw_mode = False
        else:
            print("(usage: /raw on|off)")
            return
        print(f"(raw {'ON' if self.cfg.raw_mode else 'OFF'})")

    def cmd_log(self, onoff: str) -> None:
        v = onoff.strip().lower()
        if v in ("on", "1", "true", "yes"):
            self.logger.enabled = True
        elif v in ("off", "0", "false", "no"):
            self.logger.enabled = False
        else:
            print("(usage: /log on|off)")
            return
        print(f"(log {'ON' if self.logger.enabled else 'OFF'})")

    def cmd_retry(self, n_str: str) -> None:
        try:
            n = int(n_str.strip())
        except Exception:
            print("(usage: /retry N)")
            return
        if not self.last_user:
            print("(no previous user message)")
            return
        n = max(1, min(10, n))
        for i in range(n):
            print("-" * 78)
            print(f"RETRY {i+1}/{n}")
            self._run_turn(self.last_user, write_memory=False)

    def route_command(self, line: str) -> bool:
        if not line.startswith("/"):
            return False
        parts = line.split(None, 1)
        cmd = parts[0]
        arg = parts[1] if len(parts) > 1 else ""

        if cmd in ("/exit", "/quit"):
            raise SystemExit(0)
        if cmd == "/help":
            self.cmd_help(); return True
        if cmd == "/diag":
            self.cmd_diag(); return True
        if cmd == "/health":
            self.cmd_health(); return True
        if cmd == "/save":
            print("(sqlite autocommit; nothing to do)"); return True
        if cmd == "/raw":
            self.cmd_raw(arg); return True
        if cmd == "/log":
            self.cmd_log(arg); return True
        if cmd == "/mem" and arg.strip() == "show":
            self.cmd_mem_show(); return True
        if cmd == "/facts":
            self.cmd_facts(); return True
        if cmd == "/remember":
            self.cmd_remember(arg); return True
        if cmd == "/forget":
            self.cmd_forget(arg); return True
        if cmd == "/retry":
            self.cmd_retry(arg); return True

        print("(unknown command)")
        return True

    def _maybe_summarize(self) -> None:
        if self.cfg.summarize_every <= 0:
            return
        turn_count = self.store.turns_count()
        if not should_summarize(turn_count, self.cfg.summarize_every):
            return
        latest = self.store.latest_summary()
        recent = self.store.recent_turns(min(30, self.cfg.recent_turns * 2))
        prompt = build_summary_prompt(latest, recent)
        sys.stdout.write("SABLE(summary)> ")
        sys.stdout.flush()
        text = self._call_model(prompt).strip()
        if not text:
            return
        last = self.store.get_meta_int("last_summary_turn", 0)
        self.store.save_rolling_summary(text, last + 1, turn_count)
        self.store.set_meta_int("last_summary_turn", turn_count)

    def _call_model(self, prompt: str) -> str:
        out = self.model.generate(prompt, stream=True)
        if isinstance(out, str):
            return out
        buf = []
        for chunk in out:
            sys.stdout.write(chunk)
            sys.stdout.flush()
            buf.append(chunk)
        sys.stdout.write("\n")
        sys.stdout.flush()
        return "".join(buf)

    def _run_turn(self, user_text: str, write_memory: bool = True) -> None:
        summary = self.store.latest_summary()
        facts = self.store.facts_list()
        recent = self.store.recent_turns(self.cfg.recent_turns)
        prompt = build_prompt(summary, facts, recent, user_text)

        if write_memory:
            self.store.add_turn("user", user_text, "{}")
            self.logger.log("user", user_text)

        sys.stdout.write("SABLE> ")
        sys.stdout.flush()
        assistant = self._call_model(prompt).strip()

        if write_memory:
            self.store.add_turn("assistant", assistant, "{}")
            self.logger.log("assistant", assistant)

        print(assistant + "\n")

        if self.cfg.tts_enabled and self.say_fn and assistant:
            try:
                self.say_fn(assistant)
            except Exception:
                pass

        if write_memory:
            self._maybe_summarize()

    def loop(self) -> None:
        self.banner()
        while True:
            try:
                line = input("you> ")
            except EOFError:
                print("\nEOF — exiting.")
                return
            line = line.strip()
            if not line:
                continue
            if line in ("exit", "quit"):
                return
            if self.route_command(line):
                continue

            tr = truncate(line, self.cfg.max_input_chars)
            if tr.truncated:
                print(f"(input truncated to {self.cfg.max_input_chars} chars)")
            self.last_user = tr.text
            self._run_turn(tr.text, write_memory=True)
