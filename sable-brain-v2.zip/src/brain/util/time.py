from __future__ import annotations
import time

def now_ts() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")
