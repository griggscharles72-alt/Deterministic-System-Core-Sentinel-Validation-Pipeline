from __future__ import annotations
from dataclasses import dataclass

@dataclass
class TruncResult:
    text: str
    truncated: bool

def truncate(s: str, max_chars: int) -> TruncResult:
    if s is None:
        return TruncResult("", False)
    if max_chars <= 0:
        return TruncResult(s, False)
    if len(s) > max_chars:
        return TruncResult(s[:max_chars], True)
    return TruncResult(s, False)

def one_line(s: str) -> str:
    return " ".join((s or "").split())
